from django.shortcuts import render

from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from wild_land_hunters.models import *
from django.contrib.auth import authenticate, login



def index(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        request.session['user'] = username
		
        u = User.objects.filter(userName=username,password=password)
        
        if u != None:
            
            return HttpResponseRedirect('/wild_land/')
				
        else:
            return HttpResponse("Invalid Account!")
        
    else:
        return render(request, 'wild_land_hunters/index.html')	
		
def character_page(request):
    user_name = request.session.get('user')
    context_dict = {'User_Name': user_name}
    return render(request, 'wild_land_hunters/character_page.html')
	
def register(request): 
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        email = request.POST["useremail"]
        
        if len(username)>0 & len(username)<=12:
            u = User(userName=username, password=password, userEmail=email)
            u.save()
			
			
        
            return HttpResponse("Successful!")
            
        else:
            return HttpResponse("username must between 0 and 12 characters.")

    else:
        return render(request, 'wild_land_hunters/register.html')
		
def character(request):
    return render(request, 'wild_land_hunters/character_page.html')
	

def battle(request):
    return render(request, 'wild_land_hunters/battle_page.html')