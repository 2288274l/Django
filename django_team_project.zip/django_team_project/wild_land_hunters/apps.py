from django.apps import AppConfig


class WildLandHuntersConfig(AppConfig):
    name = 'wild_land_hunters'
