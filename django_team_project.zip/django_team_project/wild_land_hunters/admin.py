from django.contrib import admin
from wild_land_hunters.models import *

admin.site.register(Category)
admin.site.register(Page)
admin.site.register(User)
admin.site.register(Character)
admin.site.register(MeleeWeapon)
admin.site.register(Gun)
admin.site.register(Animal)
admin.site.register(Map)
