from django.db import models

class Category(models.Model):
    name = models.CharField(max_length=128, unique=True)
	
    def __str__(self):
        return self.name

		
class Page(models.Model):
    category = models.ForeignKey(Category, on_delete = models.DO_NOTHING)
    title = models.CharField(max_length=128)
    url = models.URLField()
    views = models.IntegerField(default=0)
	
    def __str__(self):
        return self.title
		

class User(models.Model):
    userName = models.CharField(max_length=12)
    password = models.CharField(max_length=50)
    userEmail = models.CharField(max_length=50)
	
    def __str__(self):
        return self.userName

class Character(models.Model):
    userName = models.CharField(max_length=12)
    characterName = models.CharField(max_length=20)
	#healthPoint = models.IntegerField()
    meleeWeaponLevel = models.IntegerField()
    gunLevel = models.IntegerField()
    token = models.IntegerField()
    position = models.IntegerField()
    
    def __str__(self):
        return self.userName

class MeleeWeapon(models.Model):
    meleeWeaponLevel = models.IntegerField()
    meleeWeaponName = models.CharField(max_length=50)
    meleeWeaponAttack = models.IntegerField()
	
    def __str__(self):
        return self.meleeWeaponName

class Gun(models.Model):
    gunLevel = models.IntegerField()
    gunName = models.CharField(max_length=50)
    gunAttack = models.IntegerField()
	
    def __str__(self):
        return self.gunName

class Animal(models.Model):
    animalName = models.CharField(max_length=50)
    animalLevel = models.IntegerField()
    animalNumber = models.IntegerField()
    animalAttack = models.IntegerField()
    animalDodge = models.IntegerField()
    animalHealthPoint = models.IntegerField()
    
    def __str__(self):
        return self.animalName

class Map(models.Model):
    mapLevel = models.IntegerField()
    mapName = models.CharField(max_length=50)
	
    def __str__(self):
        return self.mapName