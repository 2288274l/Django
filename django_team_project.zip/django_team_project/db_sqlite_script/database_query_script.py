from wild_land_hunters.models import *

'''
u = User(userID='', userName='', password='', userEmail='')
u.save()

c = Character(userID='', gender='', meleeWeaponLevel='', gunLevel='', token='', position='')
c.save()

mw = MeleeWeapon(meleeWeaponLevel='', meleeWeaponName='', meleeWeaponAttack='')
mw.save()

g = Gun(gunLevel='', gunName='', gunAttack='')
g.save()

a = Animal(animalName='', animalLevel='', animalNumber='', animalAttack='', animalDodge='', animalHealthPoint='')
a.save()
'''


a = Animal(animalName='Frog', animalLevel='1', animalNumber='1', animalAttack='3', animalDodge='50', animalHealthPoint='15')
a.save()